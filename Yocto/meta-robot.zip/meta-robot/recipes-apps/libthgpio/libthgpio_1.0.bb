SUMMARY = "Biblioteca GPIO"
DESCRIPTION = "Metadatos en CMake cross-compile el control de perifericos e hilos de audio"
LICENSE = "MIT"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

# Clase CMake y la clase de dev local offline
inherit cmake externalsrc

# Ruta local donde va a estar el codigo
EXTERNALSRC = "/home/irmunoz/Taller4/cfiles/libthgpio"

# Evita que Yocto busque parches en subcarpetas locales de metadatos
EXTERNALSRC_BUILD = "/home/irmunoz/Taller4/poky-scarthgap-5.0.15/rpi4/tmp/work/raspberrypi4_64-poky-linux-gnueabi/libthgpio/1.0-r0/build"

# Indicar a Yocto que empaque la biblioteca compartida (.so) y headers (.h)
FILES:${PN} = "${libdir}/lib*.so"
FILES:${PN} += "${includedir}/*.h"
FILES:${PN} += "${datadir}/roomba-disco/audio/*.mp3"

# Vaciar el paquete -dev para evitar que intente reclamar el archivo .so plano
FILES:${PN}-dev = ""

# Desactiva validación de control para ambas variantes
INSANE_SKIP:${PN} += "dev-elf"
INSANE_SKIP:${PN}-dev += "dev-elf"


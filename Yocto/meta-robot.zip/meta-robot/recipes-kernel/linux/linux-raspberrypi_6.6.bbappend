inherit externalsrc
EXTERNALSRC = "/home/irmunoz/k-robot"

# Forzar el bypass definitivo de parches externos de internet
KERNEL_DANGLING_FEATURES_WARN_ONLY = "1"
KERNEL_VERSION_SANITY_SKIP = "1"
